package trafficLights;

/**
 * Created by Venelin on 24.3.2017 г..
 */
public enum Signal {
    RED, GREEN, YELLOW;
}
