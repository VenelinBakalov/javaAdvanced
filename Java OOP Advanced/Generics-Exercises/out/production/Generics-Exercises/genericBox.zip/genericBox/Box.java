package genericBox;

import java.util.List;

/**
 * Created by Venelin on 17.3.2017 г..
 */
public class Box<T> {

    private T data;

    public Box(T data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return data.getClass().getName() + ": " + data;
    }
}
