package militaryElite;

/**
 * Created by Venelin on 15.3.2017 г..
 */
public interface ISpy {

    String getCodeNumber();
}
