package fragileBaseClass;

/**
 * Created by Venelin on 1.3.2017 г..
 */
public class Main {

    public static void main(String[] args) {
        
    }
}
