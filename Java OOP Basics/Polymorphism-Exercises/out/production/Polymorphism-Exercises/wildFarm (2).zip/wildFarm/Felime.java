package wildFarm;

/**
 * Created by Venelin on 5.3.2017 г..
 */
public abstract class Felime extends Mammal {

    public Felime(String animalName, String animalType, Double animalWeight, String livingRegion) {
        super(animalName, animalType, animalWeight, livingRegion);
    }
}
