package wildFarm;

/**
 * Created by Venelin on 5.3.2017 г..
 */
public class Meat extends Food {

    public Meat(Integer quantity) {
        super(quantity);
    }
}
