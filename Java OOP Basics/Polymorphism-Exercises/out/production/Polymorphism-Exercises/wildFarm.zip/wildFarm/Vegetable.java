package wildFarm;

/**
 * Created by Venelin on 5.3.2017 г..
 */
public class Vegetable extends Food {

    public Vegetable(Integer quantity) {
        super(quantity);
    }
}
