package systemSplit.components;

/**
 * Created by Venelin on 9.3.2017 г..
 */
public abstract class SoftwareComponent extends Component {


    protected SoftwareComponent(String name, String type) {
        super(name, type);
    }
}
